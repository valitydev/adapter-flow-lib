package dev.vality.adapter.flow.lib.constant;

public enum Step {

    AUTH,
    PAY,
    FINISH_THREE_DS_V1,
    FINISH_THREE_DS_V2,
    CANCEL,
    REFUND,
    CHECK_STATUS,
    CHECK_STATUS_3DS_V2,
    CHECK_NEED_3DS_V2,
    CAPTURE,
    DO_NOTHING;

}
